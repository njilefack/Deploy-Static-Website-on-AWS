cloudfront URL
d3u38zsee4m7yq.cloudfront.net/index.html

S3 URL
http://staticwebsite-jilefack.s3-website-us-east-1.amazonaws.com
